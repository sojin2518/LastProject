package proj.admin.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;


public class AdminQnaResaveAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//답변 쓰고 확인 누르면 
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		session.setAttribute("id", id);
		
		String url = "DiseaseServlet?command=admin_qna_list";
	    String qseq = request.getParameter("qseq").trim();
	    String reply =request.getParameter("reply").trim();	    
	    QnaDTO qDto = new QnaDTO();
	    qDto.setQseq(Integer.parseInt(qseq));
	    qDto.setReply(reply);    	    
	    QnaDAO qDao = QnaDAO.getInstance();
	    qDao.updateQna(qDto); 	
	    response.sendRedirect(url);
	}
}
