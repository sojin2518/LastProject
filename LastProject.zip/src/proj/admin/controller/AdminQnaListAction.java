package proj.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;


public class AdminQnaListAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "admin/admin_qnaList.jsp";
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		session.setAttribute("id", id);
		MemberDAO dao = MemberDAO.getInstance();
		QnaDAO qDao = QnaDAO.getInstance();
		int adminNum = dao.adminCheck(id);
		if (adminNum == -1) {
			System.out.println(id);
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('관리자가아닙니다!');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return;
		} else {
			session.setAttribute("id", id);
			url = "admin/admin_qnaList.jsp";
		}
		int pg = 1; // 페이지 번호
		int pgSize = 15; // 한 페이지에 보여줄 글의 개수
		int total = qDao.getTotal(); // 총 게시글 개수
		if (request.getParameter("pg") != null)
			pg = Integer.parseInt(request.getParameter("pg"));
	
		int begin = (pg * pgSize) - (pgSize - 1); // (2 * 15) - (15 - 1) =30-14=16//15-14=1
		
		int end = (pg * pgSize); // (2 * 15) =30
	
		ArrayList<QnaDTO> qnaList = qDao.listAllQna(begin, end);
		int allPage = (int) Math.ceil(total / (double) pgSize); // 페이지 개수// Math.ceil 같거나 큰 정수
		int block = 10; // 한 페이지에 보여줄 페이지 번호 범위
		int beginPage = ((pg - 1) / block * block) + 1; // 보여줄 페이지의 시작
		int endPage = ((pg - 1) / block * block) + block; // 보여줄 페이지의 끝
		if (endPage > allPage) {
			endPage = allPage;
		}
		request.setAttribute("qnaList", qnaList);
		request.setAttribute("pg", pg);
		request.setAttribute("block", block);
		request.setAttribute("beginPage", beginPage);
		request.setAttribute("endPage", endPage);
		request.setAttribute("allPage", allPage);
		// 여기까지 페이징
	RequestDispatcher dispatcher = request.getRequestDispatcher(url);
	dispatcher.forward(request, response);

		
		
//		 QnaDAO qDao = QnaDAO.getInstance();
//		 ArrayList<QnaDTO> qnaList = qDao.listAllQna();
//		    request.setAttribute("qnaList", qnaList);
//		    request.getRequestDispatcher(url).forward(request, response);

	}

}
