package proj.admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.LocationDAO;
import proj.dto.LocationDTO;

public class AdminDiseaseCheckAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = "admin/admin_disease.jsp";

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		session.setAttribute("id", id);
		System.out.println(id);
		
		String disease_name = (String) session.getAttribute("admin_disease_name");
		session.setAttribute("admin_disease_name", disease_name);
		
		String disease_id = (String) session.getAttribute("admin_disease_id");



		LocationDAO dao = LocationDAO.getInstance();
		ArrayList<LocationDTO> dtos = new ArrayList<LocationDTO>();
		ArrayList<LocationDTO> dtos2 = new ArrayList<LocationDTO>();

		dtos= dao.findDiseaseCarrier(disease_name,disease_id);
		
		//중복 제거
		
		for(int i =0; i<dtos.size();i++) {
			if(!dtos2.contains(dtos.get(i))) {
				dtos2.add(dtos.get(i));
			}
		}
		
		
		request.setAttribute("dtos", dtos2);
		


		request.getRequestDispatcher(url).forward(request, response);
	}

}
