package proj.controller.memberAction;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailConfirm{
	public String connectEmail(String email){
		String to1=email; 
		String host="smtp.naver.com"; 
		String subject="인증번호 전송"; 
		String fromName="from 소진"; 
		String from="ansthwls2@naver.com"; 
		String authNum=EmailConfirm.authNum(); 
		String content="인증번호 ["+authNum+"]"; 
		
		try{
		Properties props=new Properties();
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", host);
		props.put
                       ("mail.smtp.socketFactory.class",
                        "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.port","465");
		props.put("mail.smtp.user",from);
		props.put("mail.smtp.auth","true");
		
		Session mailSession 
           = Session.getInstance(props,new javax.mail.Authenticator(){
			    protected PasswordAuthentication getPasswordAuthentication(){
				    return new PasswordAuthentication
                                        ("ansthwls2","rkwhr123"); 
			}
		});
		
		Message msg = new MimeMessage(mailSession);
		InternetAddress []address1 = {new InternetAddress(to1)};
		msg.setFrom(new InternetAddress
                      (from, MimeUtility.encodeText(fromName,"utf-8","B")));
		msg.setRecipients(Message.RecipientType.TO, address1); 
		msg.setSubject(subject); 
		msg.setSentDate(new java.util.Date()); 
		msg.setContent(content,"text/html; charset=utf-8"); 
		
		Transport.send(msg); 
		}catch(MessagingException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return authNum;
	}

    
	public static String authNum(){
		StringBuffer buffer=new StringBuffer();
		for(int i=0;i<=4;i++){
			int num=(int)(Math.random()*9+1);
			buffer.append(num);
		}
		return buffer.toString();
	}
}