package proj.controller.memberAction;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dto.MemberDTO;

public class IndexAction implements Action {

  @Override
  public void execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {    
	  HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		MemberDAO dao = MemberDAO.getInstance();
		int eMailNum = dao.eMailCheck(id);
		MemberDTO dto = dao.getMember(id);
		if (eMailNum == 1) {
			String name = dto.getName();
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("ValidMem", "yes");
			response.sendRedirect("DiseaseServlet?command=eMailCheckOk");
		} else if (eMailNum == -1) {
			String name = dto.getName();
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("ValidMem", "yes");
			response.sendRedirect("DiseaseServlet?command=eMailCheckNo");
		}
	}
}