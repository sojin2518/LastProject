package proj.controller.memberAction;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dto.MemberDTO;



public class eMailCheckOk_NEXT implements Action {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		MemberDTO dto = new MemberDTO();
		HttpSession session = request.getSession();
		String id = session.getAttribute("id").toString();
		dto.setId(id);
		MemberDAO dao = MemberDAO.getInstance();
		int ri = dao.updateCheck(dto);

		if (ri == 1) {
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('이메일인증이 완료되었습니다.');");
			writer.println("document.location.href =\"main.jsp\";");
			writer.println("</script>");
			writer.flush();
			
			return;
		} else {
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('이메일인증이 실패되었습니다.');");
			writer.println("history.go(-1);");
			writer.println("document.location.href =\"main.jsp\";");
			writer.println("</script>");
			writer.flush();
			return;

		}

	}
}
