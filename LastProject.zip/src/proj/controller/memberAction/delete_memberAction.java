package proj.controller.memberAction;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;


public class delete_memberAction implements Action {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String id = session.getAttribute("id").toString();
		String pw = request.getParameter("pw");

		// 세션에서 아이디를, DeleteForm.jsp에서 입력받은 비밀번호를 가져온다.
		// 가져온 결과를 가지고 회원정보를 삭제한다. - 삭제결과를 반환
		MemberDAO dao = MemberDAO.getInstance();
		int check = dao.deleteMember(id, pw);

		if (check == 1) {
			session.invalidate(); // 삭제했다면 세션정보를 삭제한다.
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('탈퇴가 되었습니다.');");
			writer.println("document.location.href =\"main.jsp\";");
			writer.println("</script>");
			writer.flush();
			return;

			// 비밀번호가 틀릴경우 - 삭제가 안되었을 경우
		} else {

			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('회원탈퇴를 실패하였습니다..');");
			writer.println("history.go(-1);");
			writer.println("</script>");
			writer.flush();
			return;

		}

	}
}
