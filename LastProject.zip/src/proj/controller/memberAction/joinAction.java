package proj.controller.memberAction;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dto.MemberDTO;



public class joinAction implements Action {

	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "main.jsp";

		HttpSession session = request.getSession();

		MemberDTO dto = new MemberDTO();

		dto.setId(request.getParameter("id"));
		dto.setPw(request.getParameter("pw"));
		dto.setName(request.getParameter("name"));
		dto.seteMail1(request.getParameter("eMail1"));
		dto.seteMail2(request.getParameter("eMail2"));
		dto.setAddress(request.getParameter("address"));
		dto.seteMail_Check(request.getParameter("eMail_Check"));
		dto.setAdmin(request.getParameter("admin"));

		session.setAttribute("id", request.getParameter("id"));

		MemberDAO dao = MemberDAO.getInstance();
		dao.insertMember(dto);

		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

}
