package proj.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dto.MemberDTO;

public class BoardMainCheck implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");

		session.setAttribute("id", id);

		MemberDAO dao = MemberDAO.getInstance();
		MemberDTO dto = new MemberDTO();
		int eMailNum = dao.eMailCheck(id);
		 if (id == null) {
				response.sendRedirect("DiseaseServlet?command=main");
			} else if (eMailNum == 1) {
			String name = dto.getName();
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("ValidMem", "yes");
			response.sendRedirect("DiseaseServlet?command=eMailCheckOk");
			System.out.println(name);
		} else if (eMailNum == -1) {
			String name = dto.getName();
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("ValidMem", "yes");
			response.sendRedirect("DiseaseServlet?command=eMailCheckNo");
		}

	}
}
