package proj.controller.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.LocationDAO;
import proj.dao.MemberDAO;
import proj.dto.LocationDTO;
import proj.dto.MemberDTO;

public class diseasePage implements Action {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "map/disease.jsp";
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		String eMail_Check = (String) session.getAttribute("eMail_Check");

		session.setAttribute("id", id);

		MemberDAO dao = MemberDAO.getInstance();
		int eMailNum = dao.eMailCheck(id);
		
		LocationDAO daoL = LocationDAO.getInstance();
		

		if (id == null) {

			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('로그인해주세요 !!');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return;
		} else if (eMailNum == -1) {
			System.out.println(eMail_Check);
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('이메일 인증후 이용가능합니다!!');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
		} else {

			session.setAttribute("id", id);
			System.out.println(id);
			
			ArrayList<LocationDTO> dto = daoL.getdisease(id);
			request.setAttribute("dtos", dto);
			url = "map/disease.jsp";
		}
	
		
	

		request.getRequestDispatcher(url).forward(request, response);

	}

}