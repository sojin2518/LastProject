package proj.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proj.controller.Action;
import proj.dao.QnaDAO;


public class QnaDeleteAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		
		String qseq=request.getParameter("qseq");
		QnaDAO qDao=QnaDAO.getInstance();
		qDao.deleteQna(qseq);
		new QnaListAction().execute(request, response);
		
	}

}
