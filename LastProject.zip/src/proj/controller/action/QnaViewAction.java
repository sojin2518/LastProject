package proj.controller.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proj.controller.Action;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;

public class QnaViewAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/qna/qnaView.jsp";
		/* String qseq=request.getParameter("qseq"); */
		int qseq = Integer.parseInt(request.getParameter("qseq"));
		QnaDAO qDao = QnaDAO.getInstance();
		/* QnaDTO qDto=qDao.selectOneQnaBynum(qseq); */
		QnaDTO qDto = qDao.getQna(qseq);
		request.setAttribute("qDto", qDto);

	
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}
}
