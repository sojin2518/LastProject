package proj.controller.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proj.controller.Action;
import proj.dao.BoardDAO;
import proj.dto.BoardDTO;



public class BoardCheckPassAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url=null;
		String num=request.getParameter("num");
		String pass=request.getParameter("pass");
		BoardDAO bDao=BoardDAO.getInstance();
		BoardDTO bDto=bDao.selectOneBoardBynum(num);
		if(bDto.getPass().equals(pass)) {//
			url="/board/checkSuccess.jsp";
		}else {//
			url="/board/boardCheckPass.jsp";
			
		request.setAttribute("message", "비밀번호를 다시 한번 확인해주세요");
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

}
