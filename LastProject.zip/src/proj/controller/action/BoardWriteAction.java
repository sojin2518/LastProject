package proj.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proj.controller.Action;
import proj.dao.BoardDAO;
import proj.dto.BoardDTO;

public class BoardWriteAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BoardDTO bDto = new BoardDTO();
		bDto.setName(request.getParameter("name"));
		bDto.setPass(request.getParameter("pass"));	
		bDto.setTitle(request.getParameter("title"));
		bDto.setContent(request.getParameter("content"));
		BoardDAO bDao = BoardDAO.getInstance();
		bDao.insertBoard(bDto);
		new BoardListAction().execute(request, response);
	}

}