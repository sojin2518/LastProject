package proj.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;



public class QnaWriteAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "DiseaseServlet?command=qna_list";

		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		String id = session.getAttribute("id").toString();
		QnaDTO qDto = new QnaDTO();
		
		qDto.setSubject(request.getParameter("subject"));
		qDto.setId(request.getParameter("id"));
		qDto.setContent(request.getParameter("content"));
		QnaDAO qDao = QnaDAO.getInstance();
		qDao.insertqna(qDto, qDto.getId());
		response.sendRedirect(url);
	}
}
