package proj.controller.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;

public class BoardWriteFormAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/board/boardWrite.jsp";
		HttpSession session = request.getSession();

		String id = (String)session.getAttribute("id");
		MemberDAO dao = MemberDAO.getInstance();
		int adminNum = dao.adminCheck(id);
		if (adminNum == -1) {

			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('관리자가아닙니다!');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return;
		} else {

			session.setAttribute("id", id);
			url = "/board/boardWrite.jsp";
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);

	}

}
