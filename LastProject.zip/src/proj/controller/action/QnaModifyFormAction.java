package proj.controller.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proj.controller.Action;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;



public class QnaModifyFormAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String qseq=request.getParameter("qseq");
		QnaDAO qDao=QnaDAO.getInstance();
		QnaDTO qDto=qDao.selectOneQnaBynum(qseq);
		request.setAttribute("qna", qDto);
		request.getRequestDispatcher("/qna/qnaModify.jsp").forward(request, response);


	
	}

}
