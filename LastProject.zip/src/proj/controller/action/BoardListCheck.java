package proj.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;

public class BoardListCheck implements Action {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		MemberDAO dao = MemberDAO.getInstance();
		int adminNum = dao.adminCheck(id);
		
		if (adminNum == -1) {

			session.setAttribute("id", id);
			response.sendRedirect("DiseaseServlet?command=board_list");

		} else {

			session.setAttribute("id", id);
			response.sendRedirect("DiseaseServlet?command=admin_board_list");
		}

	}
}
