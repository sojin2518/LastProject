﻿package proj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import proj.dto.QnaDTO;
import util.DBManager;

public class QnaDAO {

	private QnaDAO() {
	}

	private static QnaDAO instance = new QnaDAO();

	public static QnaDAO getInstance() {
		return instance;
	}
	
	
	public ArrayList<QnaDTO>listQna(int begin, int end){
		ArrayList<QnaDTO>qnaList=new ArrayList<QnaDTO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql="SELECT Rownum as rn, qseq, subject, content, id, indate, reply, rep FROM (SELECT Rownum as rn,qseq, subject, content, id, indate, reply, rep FROM (SELECT * FROM qna ORDER BY qseq DESC))where rn >=? AND rn <=?";
	
		try {
			conn = DBManager.getConnection();		
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, begin);
			pstmt.setInt(2, end);			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				QnaDTO qDto=new QnaDTO();
				qDto.setQseq(rs.getInt("qseq"));// 글번호
				qDto.setSubject(rs.getString("subject"));// 제목
				qDto.setContent(rs.getString("content"));// 내용
				qDto.setId(rs.getString("id"));// 이름
				qDto.setIndate(rs.getTimestamp("indate"));// 작성일
				qDto.setReply(rs.getString("reply"));// 답변
				qDto.setRep(rs.getString("rep"));//
				qnaList.add(qDto);
	}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return qnaList;
	}
	
	
	public int getTotal() {
		int cnt = 0;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "SELECT COUNT(*)cnt FROM qna";
		try {
			conn = DBManager.getConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery(sql);
			if (rs.next())
				cnt = rs.getInt("cnt");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, stmt, rs);
		}
		return cnt;
	} // getTotal() : 총 게시글의 수
	

	
	public QnaDTO getQna(int seq) {
		QnaDTO qDto = null;
		String sql = "select * from qna where qseq=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, seq);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				qDto = new QnaDTO();
				qDto.setQseq(seq);
				qDto.setSubject(rs.getString("subject"));
				qDto.setContent(rs.getString("content"));
				qDto.setId(rs.getString("id"));
				qDto.setIndate(rs.getTimestamp("indate"));
				qDto.setReply(rs.getString("reply"));
				qDto.setRep(rs.getString("rep"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
		return qDto;
	}


	// qna 삽입하기
	public void insertqna(QnaDTO qDto, String session_id) {
		String sql = "insert into qna (qseq, subject, content, id) values(qna_seq.nextval, ?, ?, ?)";

		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, qDto.getSubject());
			pstmt.setString(2, qDto.getContent());
		//	pstmt.setString(3, qDto.getId());
			pstmt.setString(3, session_id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	/* qna수정하기  * * */
	public void modifyQna(QnaDTO qDto) {
		String sql = "update qna set subject=?,content=? where qseq=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, qDto.getSubject());
			pstmt.setString(2, qDto.getContent());
			pstmt.setInt(3, qDto.getQseq());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}//여기 됨

	public QnaDTO selectOneQnaBynum(String qseq) {
		String sql="select * from qna where qseq=?";
		QnaDTO qDto=null;
		Connection  conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, qseq);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				qDto=new QnaDTO();
				qDto.setQseq(rs.getInt("qseq"));
				qDto.setSubject(rs.getString("subject"));
				qDto.setContent(rs.getString("content"));
				/*qDto.setId(rs.getString("id"));*/
				qDto.setIndate(rs.getTimestamp("indate"));
				qDto.setReply(rs.getString("reply"));
				qDto.setRep(rs.getString("rep"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
		return qDto;
	}
		
	
	/*qna 삭제하기*/
	public void deleteQna(String qseq) {
	      String sql = "delete qna where qseq=?";
	      Connection conn = null;
	      PreparedStatement pstmt =null;
	      try {
	         conn = DBManager.getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, qseq);
	         pstmt.executeQuery();
	         
	      }catch(SQLException e) {
	         e.printStackTrace();
	      }finally {
	         DBManager.close(conn, pstmt);
	      }
	   }

	
	



	/*
	 * * 관리자 모드에서 필요한 메소드
	 */
	public ArrayList<QnaDTO>listAllQna(int begin, int end){
		ArrayList<QnaDTO>qnaList=new ArrayList<QnaDTO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql="SELECT Rownum as rn, qseq, subject, content, id, indate, reply, rep FROM (SELECT Rownum as rn,qseq, subject, content, id, indate, reply, rep FROM (SELECT * FROM qna ORDER BY qseq DESC))where rn >=? AND rn <=?";
	
		try {
			conn = DBManager.getConnection();		
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, begin);
			pstmt.setInt(2, end);			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				QnaDTO qDto=new QnaDTO();
				qDto.setQseq(rs.getInt("qseq"));// 글번호
				qDto.setSubject(rs.getString("subject"));// 제목
				qDto.setContent(rs.getString("content"));// 내용
				qDto.setId(rs.getString("id"));// 이름
				qDto.setIndate(rs.getTimestamp("indate"));// 작성일
				qDto.setReply(rs.getString("reply"));// 답변
				qDto.setRep(rs.getString("rep"));//
				qnaList.add(qDto);
				
	}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return qnaList;
	}
	
	

	public void updateQna(QnaDTO qDto) {
		String sql = "update qna set reply=?, rep='2' where qseq=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, qDto.getReply());
			pstmt.setInt(2, qDto.getQseq());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	
	
	
	public void admodifyQna(QnaDTO qDto) {
		String sql = "update qna set reply=?,rep='2'  where qseq=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, qDto.getReply());
			pstmt.setInt(2, qDto.getQseq());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
}
