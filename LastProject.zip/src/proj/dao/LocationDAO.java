package proj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import proj.dto.LocationDTO;
import proj.dto.MemberDTO;

public class LocationDAO {

	private static LocationDAO instance = new LocationDAO();

	private LocationDAO() {
	}

	public static LocationDAO getInstance() {
		return instance;
	}

	private Connection getConnection() {

		Context context = null;
		DataSource dataSource = null;
		Connection connection = null;
		try {
			context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/myoracle");
			connection = dataSource.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return connection;
	}

	public ArrayList<LocationDTO> getdisease(String id) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		LocationDTO dto = null;
		ArrayList<LocationDTO> dtos = new ArrayList<LocationDTO>();
		String query = "select * from location where id = ? order by carrier DESC";

		try {
			connection = getConnection();
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				dto = new LocationDTO();
				dto.setId(rs.getString("id"));
				dto.setAndr_address(rs.getString("andr_address"));
				dto.setAndr_date(rs.getTimestamp("andr_date"));
				dto.setCarrier(rs.getString("carrier"));
				dtos.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return dtos;

	}

	public ArrayList<LocationDTO> getdiseaseAll() {

		ArrayList<LocationDTO> dtos = new ArrayList<LocationDTO>();
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "select * from project";

		try {
			connection = getConnection();
			pstmt = connection.prepareStatement(query);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				LocationDTO dto = new LocationDTO();
				dto.setId(rs.getString("id"));
				dto.setAndr_address(rs.getString("andr_address"));
				dto.setAndr_date(rs.getTimestamp("andr_date"));
				dto.setCarrier(rs.getString("carrier"));
				dtos.add(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return dtos;
	}

	public int setdiseaseCarrier(String id, String name) {

		ArrayList<LocationDTO> dtos = new ArrayList<LocationDTO>();
		Connection connection = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		String query = "update location set carrier=? where id = ?";

		try {
			connection = getConnection();
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setString(2, id);

			rs = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return rs;
	}

	public ArrayList<LocationDTO> findDiseaseCarrier(String disease_name, String id) {

		ArrayList<LocationDTO> dtos_return = new ArrayList<LocationDTO>();

		ArrayList<LocationDTO> dtos = new ArrayList<LocationDTO>();
		ArrayList<LocationDTO> dtos2 = new ArrayList<LocationDTO>();
		LocationDTO dto = null;
		Connection connection = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;

		ResultSet rs = null;
		int rn = 0;
		String query = "select * from location where carrier=?";
		String query_f = "select * from location";
		String query_u = "update location set carrier=? where andr_address=? and andr_date=?";

		try {
			connection = getConnection();
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, disease_name);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				dto = new LocationDTO();
				dto.setId(rs.getString("id"));
				dto.setAndr_address(rs.getString("andr_address"));
				dto.setAndr_date(rs.getTimestamp("andr_date"));
				dto.setCarrier(rs.getString("carrier"));
				dtos.add(dto);
			}

			pstmt2 = connection.prepareStatement(query_f);
			rs = pstmt2.executeQuery();

			while (rs.next()) {
				dto = new LocationDTO();
				dto.setId(rs.getString("id"));
				dto.setAndr_address(rs.getString("andr_address"));
				dto.setAndr_date(rs.getTimestamp("andr_date"));
				dto.setCarrier(rs.getString("carrier"));
				dtos2.add(dto);

			}

			ArrayList<LocationDTO> dtos3 = new ArrayList<LocationDTO>();
			for (LocationDTO ldto1 : dtos) {
				for (LocationDTO ldto2 : dtos2) {
					// 주소와 시간이 같으면
					if (String.valueOf(ldto1.getAndr_date()).substring(0, 16)
							.equals(String.valueOf(ldto2.getAndr_date()).substring(0, 16))
							&& ldto1.getAndr_address().equals(ldto2.getAndr_address())) {
						// System.out.println(ldto1.getId() + ldto1.getAndr_address() +
						// ldto1.getAndr_date());
						// System.out.println(ldto2.getId() + ldto2.getAndr_address() +
						// ldto2.getAndr_date());
						dtos3.add(ldto2);
					}
				}
				// System.out.println(String.valueOf(ldto1.getAndr_date()).substring(0, 16));
			}

			String first_carrier = disease_name + "1차";
			System.out.println(first_carrier);
			for (LocationDTO udto : dtos3) {
				pstmt3 = connection.prepareStatement(query_u);
				if (udto.getId().equals(id)) {
					pstmt3.setString(1, disease_name);
				} else {
					pstmt3.setString(1, first_carrier);
				}
				pstmt3.setString(2, udto.getAndr_address());
				pstmt3.setTimestamp(3, udto.getAndr_date());
				rn = pstmt3.executeUpdate();
				if (udto.getId().equals(id)) {
					udto.setCarrier(disease_name);
				} else {
					udto.setCarrier(first_carrier);
				}
				dtos_return.add(udto);
			}

			System.out.println(" rn : " + rn);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				pstmt2.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return dtos_return;
	}
}
