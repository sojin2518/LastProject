package proj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import proj.dto.BoardDTO;
import util.DBManager;

public class BoardDAO {
	private BoardDAO() {

	}

	private static BoardDAO instance = new BoardDAO();

	public static BoardDAO getInstance() {
		return instance;
	}
	
//	public List<BoardDTO> selectAllBoards() {
//		String sql = "select * from board order by num desc ";
//		List<BoardDTO> list = new ArrayList<BoardDTO>();
//		Connection conn = null;
//		Statement stmt = null;
//		ResultSet rs = null;
//
//	
//		try {
//			conn = DBManager.getConnection();
//			stmt = conn.createStatement();
//			rs = stmt.executeQuery(sql);
//			
//			while (rs.next()) {
//				BoardDTO bDto = new BoardDTO();
//				bDto.setNum(rs.getInt("num"));
//				bDto.setName(rs.getString("name"));
//				bDto.setPass(rs.getString("pass"));
//				bDto.setTitle(rs.getString("title"));
//				bDto.setContent(rs.getString("content"));
//				bDto.setReadcount(rs.getInt("readcount"));
//				bDto.setWritedate(rs.getTimestamp("writedate"));
//
//				list.add(bDto);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			DBManager.close(conn, stmt, rs);
//		}
//		return list;
//
//	}

	
	
	//수정 _리스트 가져오기
	public ArrayList<BoardDTO> listBoard(int begin, int end) {
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql ="SELECT Rownum as rn, num, name, pass, title, content, readcount, writedate FROM (SELECT Rownum as rn, num, name, pass, title, content, readcount, writedate FROM (SELECT * FROM board ORDER BY num DESC))where rn >=? AND rn <=?";
		try {
			conn = DBManager.getConnection();		
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, begin);
			pstmt.setInt(2, end);			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardDTO bDto = new BoardDTO();
				bDto.setNum(rs.getInt("num"));
				bDto.setName(rs.getString("name"));
				bDto.setPass(rs.getString("pass"));
				bDto.setTitle(rs.getString("title"));
				bDto.setContent(rs.getString("content"));
				bDto.setReadcount(rs.getInt("readcount"));
				bDto.setWritedate(rs.getTimestamp("writedate"));
				list.add(bDto);
			} // while
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return list;
	}
	
	
	
	//총 글 수 구하기
	public int getTotal() {
		int cnt = 0;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "SELECT COUNT(*)cnt FROM board";
		try {
			conn = DBManager.getConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery(sql);
			if (rs.next())
				cnt = rs.getInt("cnt");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, stmt, rs);
		}
		return cnt;
	} // getTotal() : 총 게시글의 수
	
	

	public void insertBoard(BoardDTO bDto) {
		String sql = "insert into board (num, name, pass, title, content,readcount,writedate) values(board_seq.nextval,?,?,?,?,0,SYSDATE)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bDto.getName());
			pstmt.setString(2, bDto.getPass());
			pstmt.setString(3, bDto.getTitle());
			pstmt.setString(4, bDto.getContent());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}
//조회수 올리기
	public void updateReadCount(String num) {
		String sql = "update board set readcount=readcount+1 where num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	public BoardDTO selectOneBoardBynum(String num) {
		String sql = "select * from board where num = ?";
		BoardDTO bDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bDto = new BoardDTO();
				bDto.setNum(rs.getInt("num"));
				bDto.setName(rs.getString("name"));
				bDto.setPass(rs.getString("pass"));
				bDto.setTitle(rs.getString("title"));
				bDto.setContent(rs.getString("content"));
				bDto.setWritedate(rs.getTimestamp("writedate"));
				bDto.setReadcount(rs.getInt("readcount"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return bDto;
	}

	// 게시판 수정하기
	public void updateBoard(BoardDTO bDto) {
		String sql = "update board set name=?,pass=?," + "title=?,content=? where num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bDto.getName());
			pstmt.setString(2, bDto.getPass());
			pstmt.setString(3, bDto.getTitle());
			pstmt.setString(4, bDto.getContent());
			pstmt.setInt(5, bDto.getNum());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	// 비밀번호체크
	public BoardDTO checkPassWord(String pass, String num) {
		String sql = "select * from board where pass=? and num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BoardDTO bDto = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pass);
			pstmt.setString(2, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bDto = new BoardDTO();
				bDto.setNum(rs.getInt("num"));
				bDto.setName(rs.getString("name"));

				bDto.setPass(rs.getString("pass"));
				bDto.setTitle(rs.getString("title"));
				bDto.setContent(rs.getString("content"));
				bDto.setReadcount(rs.getInt("readcount"));
				bDto.setWritedate(rs.getTimestamp("writedate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}

		return bDto;
	}

	// 게시물삭제하기
	public void deleteBoard(String num) {
		String sql = "delete board where num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);
			pstmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

}